@extends('layouts.admin')
@section('title', $member ? 'Edit Pengurus' : 'Tambah Pengurus')
@section('content')
<div class="card" style="max-width:700px">
  <div class="card-header"><i class="bi bi-people me-2"></i>{{ $member ? 'Edit Pengurus' : 'Tambah Pengurus' }}</div>
  <div class="card-body">
    @if($errors->any())
      <div class="alert alert-danger">
        <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
      </div>
    @endif
    <form method="POST" action="{{ $member ? route('admin.pengurus.update', $member->id) : route('admin.pengurus.store') }}" enctype="multipart/form-data">
      @csrf
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label fw-semibold">Tahun Kepengurusan *</label>
          <select name="management_year_id" class="form-select" required>
            @foreach($years as $y)
              <option value="{{ $y->id }}" {{ old('management_year_id', $member?->management_year_id) == $y->id ? 'selected' : '' }}>{{ $y->year_label }}</option>
            @endforeach
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Kementerian *</label>
          <select name="ministry_id" id="ministry_id" class="form-select" required>
            <option value="">-- Pilih --</option>
            @foreach($ministries as $m)
              <option value="{{ $m->id }}" {{ old('ministry_id', $member?->ministry_id) == $m->id ? 'selected' : '' }}>{{ $m->name }}</option>
            @endforeach
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Departemen <small class="text-muted">(kosongkan jika Menteri)</small></label>
          <select name="department_id" id="department_id" class="form-select">
            <option value="">-- Tidak Ada --</option>
            @foreach($departments as $d)
              <option value="{{ $d->id }}" {{ old('department_id', $member?->department_id) == $d->id ? 'selected' : '' }}>{{ $d->name }}</option>
            @endforeach
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Role *</label>
          <select name="role" class="form-select" required>
            @foreach(['menteri'=>'Menteri','koordinator'=>'Koordinator','staff'=>'Staff'] as $k=>$v)
              <option value="{{ $k }}" {{ old('role', $member?->role ?? 'staff') === $k ? 'selected' : '' }}>{{ $v }}</option>
            @endforeach
          </select>
        </div>
        <div class="col-12">
          <div class="form-check">
            <input type="checkbox" name="is_head" id="is_head" class="form-check-input" value="1" {{ old('is_head', $member?->is_head) ? 'checked' : '' }}>
            <label for="is_head" class="form-check-label fw-semibold">Tandai sebagai <strong>Kepala Departemen</strong></label>
          </div>
        </div>
        <div class="col-md-6"><label class="form-label fw-semibold">Nama Lengkap *</label><input type="text" name="full_name" class="form-control" value="{{ old('full_name', $member?->full_name) }}" required></div>
        <div class="col-md-6"><label class="form-label fw-semibold">NIM</label><input type="text" name="nim" class="form-control" value="{{ old('nim', $member?->nim) }}"></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Jabatan (Tampilan) *</label><input type="text" name="position" class="form-control" value="{{ old('position', $member?->position) }}" placeholder="Menteri / Kepala Departemen / Staff" required></div>
        <div class="col-md-6"><label class="form-label fw-semibold">Urutan</label><input type="number" name="sort_order" class="form-control" value="{{ old('sort_order', $member?->sort_order ?? 0) }}"></div>
        <div class="col-12">
          <label class="form-label fw-semibold">Foto</label>
          <input type="file" name="photo_path" class="form-control" accept="image/*">
          @if($member?->photo_path)
            <img src="{{ asset('storage/'.$member->photo_path) }}" class="mt-2 rounded" style="height:80px" loading="lazy">
          @endif
        </div>
      </div>
      <div class="d-flex gap-2 mt-4">
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i>Simpan</button>
        <a href="{{ route('admin.pengurus.index') }}" class="btn btn-outline-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>
@endsection
@section('scripts')
<script>
document.getElementById('ministry_id').addEventListener('change', function () {
  const ministryId = this.value;
  const deptSelect = document.getElementById('department_id');
  deptSelect.innerHTML = '<option value="">-- Tidak Ada --</option>';
  if (!ministryId) return;
  fetch(`/api/departments/${ministryId}`)
    .then(r => r.json())
    .then(depts => {
      depts.forEach(d => {
        const opt = document.createElement('option');
        opt.value = d.id;
        opt.textContent = d.name;
        deptSelect.appendChild(opt);
      });
    });
});
</script>
@endsection
