@extends('layouts.admin')
@section('title','Pengurus')
@section('content')
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="bi bi-people me-2"></i>Pengurus</span>
    <a href="{{ route('admin.pengurus.create') }}" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Pengurus</a>
  </div>
  <div class="card-body">
    <form method="GET" class="mb-3" style="max-width:280px">
      <select name="year_id" class="form-select" onchange="this.form.submit()">
        @foreach($years as $y)
          <option value="{{ $y->id }}" {{ $selected_year == $y->id ? 'selected' : '' }}>{{ $y->year_label }}</option>
        @endforeach
      </select>
    </form>
    <div class="table-responsive">
    <table class="table table-hover mb-0">
      <thead class="table-light"><tr><th>#</th><th>Foto</th><th>Nama</th><th>Jabatan</th><th>Kementerian</th><th>Departemen</th><th>Kepala?</th><th>Aksi</th></tr></thead>
      <tbody>
        @forelse($members as $i => $m)
        <tr>
          <td>{{ $i+1 }}</td>
          <td>
            @if($m->photo_path)
              <img src="{{ asset('storage/'.$m->photo_path) }}" style="width:36px;height:36px;border-radius:50%;object-fit:cover" loading="lazy">
            @else
              <i class="bi bi-person-circle text-muted fs-4"></i>
            @endif
          </td>
          <td><strong>{{ $m->full_name }}</strong></td>
          <td><span class="badge bg-light text-dark">{{ $m->position }}</span></td>
          <td><small>{{ $m->ministry?->name }}</small></td>
          <td><small>{{ $m->department?->name ?? '-' }}</small></td>
          <td>
            @if($m->is_head)
              <span class="badge bg-success">Kepala</span>
            @else
              <span class="text-muted">-</span>
            @endif
          </td>
          <td>
            <div class="d-flex gap-1">
              <a href="{{ route('admin.pengurus.edit', $m->id) }}" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
              <form method="POST" action="{{ route('admin.pengurus.destroy', $m->id) }}" onsubmit="return confirm('Hapus pengurus ini?')">
                @csrf<button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
        @empty
          <tr><td colspan="8" class="text-center text-muted py-4">Belum ada pengurus.</td></tr>
        @endforelse
      </tbody>
    </table>
    </div>
  </div>
</div>
@endsection
