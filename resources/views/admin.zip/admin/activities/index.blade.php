@extends('layouts.admin')
@section('title','Jadwal Peminjaman Tempat')
@section('content')
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="bi bi-calendar-event me-2"></i>Jadwal Peminjaman Tempat</span>
    <a href="{{ route('admin.kegiatan.create') }}" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Jadwal</a>
  </div>
  <div class="card-body p-0">
    <table class="table table-hover mb-0">
      <thead class="table-light"><tr><th>#</th><th>Kegiatan</th><th>Peminjam</th><th>Tanggal</th><th>Waktu</th><th>Tempat</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
        @php $sc=['menunggu'=>'bg-warning','disetujui'=>'bg-success','ditolak'=>'bg-danger'];$sl=['menunggu'=>'Menunggu','disetujui'=>'Disetujui','ditolak'=>'Ditolak']; @endphp
        @forelse($activities as $i => $a)
        <tr>
          <td>{{ $i+1 }}</td><td><strong>{{ $a->title }}</strong></td><td><small>{{ $a->borrower_name ?? '-' }}</small></td>
          <td>{{ $a->activity_date->format('d M Y') }}</td>
          <td><small>{{ $a->start_time ? substr($a->start_time,0,5).' - '.substr($a->end_time,0,5) : '-' }}</small></td>
          <td><small>{{ $a->location ?? '-' }}</small></td>
          <td><span class="badge {{ $sc[$a->status] ?? 'bg-secondary' }}">{{ $sl[$a->status] ?? $a->status }}</span></td>
          <td>
            <div class="d-flex gap-1">
              @if($a->status === 'menunggu')
                <form method="POST" action="{{ route('admin.kegiatan.approve', $a->id) }}">@csrf<button class="btn btn-sm btn-outline-success" title="Setujui"><i class="bi bi-check-lg"></i></button></form>
                <form method="POST" action="{{ route('admin.kegiatan.reject', $a->id) }}">@csrf<button class="btn btn-sm btn-outline-danger" title="Tolak"><i class="bi bi-x-lg"></i></button></form>
              @endif
              <a href="{{ route('admin.kegiatan.edit', $a->id) }}" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
              <form method="POST" action="{{ route('admin.kegiatan.destroy', $a->id) }}" onsubmit="return confirm('Hapus?')">@csrf<button class="btn btn-sm btn-outline-secondary"><i class="bi bi-trash"></i></button></form>
            </div>
          </td>
        </tr>
        @empty<tr><td colspan="8" class="text-center text-muted py-4">Belum ada jadwal.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection
