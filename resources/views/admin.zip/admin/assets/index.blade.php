@extends('layouts.admin')
@section('title','Manajemen Asset')
@section('content')
<div class="card mb-3">
  <div class="card-header"><i class="bi bi-cloud-upload me-2"></i>Upload Asset Baru</div>
  <div class="card-body">
    <form method="POST" action="{{ route('admin.asset.store') }}" enctype="multipart/form-data">
      @csrf
      <div class="row g-3 align-items-end">
        <div class="col-md-3"><label class="form-label fw-semibold">Judul</label><input type="text" name="title" class="form-control" placeholder="Opsional"></div>
        <div class="col-md-3"><label class="form-label fw-semibold">Kategori</label><select name="category" class="form-select" required>@foreach(['logo_kabinet'=>'Logo Kabinet','logo_kementerian'=>'Logo Kementerian','foto_pengurus'=>'Foto Pengurus','banner'=>'Banner Website','dokumentasi'=>'Dokumentasi Kegiatan','lainnya'=>'Lainnya'] as $k=>$v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
        <div class="col-md-4"><label class="form-label fw-semibold">File</label><input type="file" name="file_path" class="form-control" required></div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary w-100"><i class="bi bi-upload me-1"></i>Upload</button></div>
      </div>
    </form>
  </div>
</div>
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="bi bi-images me-2"></i>Daftar Asset</span>
    <form method="GET" style="max-width:200px"><select name="category" class="form-select form-select-sm" onchange="this.form.submit()"><option value="">Semua</option>@foreach(['logo_kabinet','logo_kementerian','foto_pengurus','banner','dokumentasi','lainnya'] as $c)<option value="{{ $c }}" {{ $category===$c?'selected':'' }}>{{ \App\Models\Asset::categoryLabel($c) }}</option>@endforeach</select></form>
  </div>
  <div class="card-body">
    <div class="row g-3">
      @forelse($assets as $a)
      <div class="col-md-2">
        <div class="border rounded-3 p-2 text-center h-100">
          @if(in_array(strtolower($a->file_type ?? ''),['jpg','jpeg','png','webp','gif']))
            <img src="{{ asset('storage/'.$a->file_path) }}" class="mb-2 rounded" style="height:80px;width:100%;object-fit:cover">
          @else
            <div class="mb-2 d-flex align-items-center justify-content-center bg-light rounded" style="height:80px"><i class="bi bi-file-earmark fs-2 text-muted"></i></div>
          @endif
          <small class="d-block fw-semibold text-truncate">{{ $a->title ?: 'Untitled' }}</small>
          <small class="text-muted d-block" style="font-size:.7rem">{{ \App\Models\Asset::categoryLabel($a->category) }}</small>
          <form method="POST" action="{{ route('admin.asset.destroy', $a->id) }}" onsubmit="return confirm('Hapus?')" class="mt-1">@csrf<button class="btn btn-sm btn-outline-danger w-100"><i class="bi bi-trash"></i></button></form>
        </div>
      </div>
      @empty<p class="text-center text-muted py-4">Belum ada asset.</p>
      @endforelse
    </div>
  </div>
</div>
@endsection
