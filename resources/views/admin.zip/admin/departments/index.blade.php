@extends('layouts.admin')
@section('title','Departemen')
@section('content')
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="bi bi-diagram-3 me-2"></i>Departemen</span>
    <a href="{{ route('admin.departemen.create') }}" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg me-1"></i>Tambah Departemen</a>
  </div>
  <div class="card-body p-0">
    <table class="table table-hover mb-0">
      <thead class="table-light"><tr><th>#</th><th>Nama Departemen</th><th>Kementerian</th><th>Urutan</th><th>Aksi</th></tr></thead>
      <tbody>
        @forelse($departments as $i => $d)
        <tr>
          <td>{{ $i+1 }}</td><td><strong>{{ $d->name }}</strong></td>
          <td><span class="badge bg-light text-dark">{{ $d->ministry?->name }}</span></td>
          <td>{{ $d->sort_order }}</td>
          <td><div class="d-flex gap-1">
            <a href="{{ route('admin.departemen.edit', $d->id) }}" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
            <form method="POST" action="{{ route('admin.departemen.destroy', $d->id) }}" onsubmit="return confirm('Hapus departemen ini?')">@csrf<button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form>
          </div></td>
        </tr>
        @empty<tr><td colspan="5" class="text-center text-muted py-4">Belum ada departemen.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection
