<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Login Admin - BEM Polmed</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:linear-gradient(135deg,#4a1e8a,#7c3aed);min-height:100vh;display:flex;align-items:center}.login-card{border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.3);border:none}.btn-primary{background:linear-gradient(135deg,#4a1e8a,#7c3aed);border:none}</style>
</head>
<body>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-4">
      <div class="card login-card">
        <div class="card-header text-white text-center py-4" style="background:linear-gradient(135deg,#4a1e8a,#7c3aed);border-radius:16px 16px 0 0">
          <h4 class="mb-0 fw-bold">🏛️ BEM Polmed</h4><small>Admin Dashboard</small>
        </div>
        <div class="card-body p-4">
          @if(session('error'))<div class="alert alert-danger">{{ session('error') }}</div>@endif
          <form method="POST" action="{{ route('admin.login.post') }}">
            @csrf
            <div class="mb-3"><label class="form-label fw-semibold">Email</label><input type="email" name="email" class="form-control" required placeholder="admin@bempolmed.ac.id"></div>
            <div class="mb-4"><label class="form-label fw-semibold">Password</label><input type="password" name="password" class="form-control" required></div>
            <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Masuk</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
